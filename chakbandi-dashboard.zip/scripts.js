let currentUser = null;

const users = [
  { id: "user1", password: "pass123", district: "Lucknow" },
  { id: "user2", password: "pass456", district: "Varanasi" }
];

const tehsils = {
  "Lucknow": ["Lucknow", "Malihabad", "Bakshi Ka Talab"],
  "Varanasi": ["Varanasi", "Pindra", "Arajiline"]
};

function login() {
  const uid = document.getElementById("userId").value;
  const pwd = document.getElementById("password").value;
  const user = users.find(u => u.id === uid && u.password === pwd);
  
  if (user) {
    currentUser = user;
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("dataEntry").style.display = "block";
    document.getElementById("dashboard").style.display = "block";
    document.getElementById("districtName").innerText = user.district;
    populateTehsil(user.district);
    populateTable();
  } else {
    document.getElementById("loginMsg").innerText = "❌ अमान्य यूज़र ID या पासवर्ड";
  }
}

function populateTehsil(district) {
  const select = document.getElementById("tehsilSelect");
  select.innerHTML = "";
  tehsils[district].forEach(t => {
    const opt = document.createElement("option");
    opt.value = t;
    opt.textContent = t;
    select.appendChild(opt);
  });
}

function saveData() {
  alert("✅ Data saved successfully for " + currentUser.district);
}

function populateTable() {
  const tbody = document.querySelector("#reportTable tbody");
  tbody.innerHTML = `
    <tr>
      <td>${currentUser.district}</td>
      <td>120</td>
      <td>10</td><td>20</td><td>25</td>
      <td>30</td><td>15</td><td>10</td><td>10</td>
    </tr>`;
}

function downloadExcel() {
  alert("📊 Excel report downloaded");
}

function downloadPDF() {
  alert("📄 PDF report downloaded");
}